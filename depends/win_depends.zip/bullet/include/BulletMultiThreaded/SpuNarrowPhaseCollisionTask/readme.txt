Empty placeholder for future Libspe2 SPU task
